/*
 * 
 * WordPres版微信小程序
 * author: Frank
 * organization: 红为网络 hongweiit.com
 * github:    https://github.com/hongweiit
 * 技术支持微信号：602732212
 * Copyright (c) 2017 https://www.hongweiit.com All rights reserved.
 * 
 */

var util = require('../../utils/util.js')
Page({
  data: {
    logs: []
  },
  onLoad: function () {
    this.setData({
      logs: (wx.getStorageSync('logs') || []).map(function (log) {
        return util.formatTime(new Date(log))
      })
    })
  }
})
